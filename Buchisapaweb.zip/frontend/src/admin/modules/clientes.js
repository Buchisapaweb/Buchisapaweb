(function(){
  'use strict';
  let customers=[];
  const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  async function fetchCustomers(force=false){
    const box=document.getElementById('clientes-table-body'); if(!box) return;
    box.innerHTML='<tr><td colspan="5"><div class="admin-empty loading">Cargando clientes...</div></td></tr>';
    try { customers=(await window.AdminApi.getUsers(force)).filter(u=>u.role!=='admin' && u.isAdmin!==true); renderCustomers(); }
    catch(e){ customers=[]; box.innerHTML='<tr><td colspan="5"><div class="admin-empty">No se pudieron cargar los clientes.</div></td></tr>'; }
  }
  function renderCustomers(){
    const q=(document.getElementById('clientes-search')?.value||'').toLowerCase().trim();
    const list=customers.filter(u=>[u.name,u.email,u.phone,u.docNumber].join(' ').toLowerCase().includes(q));
    const body=document.getElementById('clientes-table-body'); if(!body) return;
    const total=document.getElementById('clientes-total'); const verified=document.getElementById('clientes-verified'); const today=document.getElementById('clientes-today');
    if(total) total.textContent=customers.length; if(verified) verified.textContent=customers.filter(u=>u.emailVerified).length;
    const day=new Date().toDateString(); if(today) today.textContent=customers.filter(u=>u.createdAt && new Date(u.createdAt).toDateString()===day).length;
    body.innerHTML=list.length?list.map((u,i)=>`<tr><td><div class="customer-cell"><span class="customer-avatar">${esc((u.name||'C').charAt(0).toUpperCase())}</span><div><strong>${esc(u.name||'Sin nombre')}</strong><small>${esc(u.email||'')}</small></div></div></td><td>${esc(u.phone||'—')}</td><td>${esc(u.docNumber||'—')}</td><td><span class="status-chip ${u.emailVerified?'success':'warning'}">${u.emailVerified?'Verificado':'Pendiente'}</span></td><td><span class="customer-date">${u.createdAt?new Date(u.createdAt).toLocaleDateString('es-PE'): '—'}</span></td></tr>`).join(''):`<tr><td colspan="5"><div class="admin-empty">No hay clientes que coincidan con la búsqueda.</div></td></tr>`;
  }
  function init(){ const input=document.getElementById('clientes-search'); input?.addEventListener('input',renderCustomers); fetchCustomers(); }
  window.fetchCustomers=fetchCustomers; window.renderCustomers=renderCustomers; document.addEventListener('DOMContentLoaded',init);
})();
