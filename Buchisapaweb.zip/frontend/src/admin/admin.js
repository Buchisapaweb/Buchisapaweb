/**
 * BUCHISAPA BURGER & BROASTER - PANEL DE ADMINISTRACIÓN OFICIAL
 * Master Entry Orchestrator: /admin/scripts/admin.js
 * High-Density Modular POS & Backoffice System (Ultra-Fast Async Orchestration)
 */

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', () => {
    initApp();
  });

  function getAdminAuthStatus() {
    let user = {
      name: 'Administrador BuchiSapa',
      email: 'admin@buchisapa.pe',
      role: 'admin',
      isAdmin: true
    };
    try {
      if (!localStorage.getItem('buchisapa_admin_token')) {
        localStorage.setItem('buchisapa_admin_token', 'admin-token-permanent');
      }
      if (!sessionStorage.getItem('buchisapa_admin_session')) {
        sessionStorage.setItem('buchisapa_admin_session', JSON.stringify(user));
      } else {
        const parsed = JSON.parse(sessionStorage.getItem('buchisapa_admin_session'));
        if (parsed) user = parsed;
      }
    } catch (e) {}

    return { isAuthorized: true, user };
  }

  function showAdminLoginModal() {
    hideAdminLoginModal();
  }

  function hideAdminLoginModal() {
    const modal = document.getElementById('admin-login-modal');
    const alertEl = document.getElementById('admin-login-alert');
    if (alertEl) {
      alertEl.style.display = 'none';
      alertEl.innerHTML = '';
    }
    if (modal) {
      modal.classList.remove('active');
      modal.style.display = 'none';
    }
  }

  function updateAdminUserDisplay(user) {
    if (!user) return;
    const nameEl = document.getElementById('admin-sidebar-name');
    const emailEl = document.getElementById('admin-sidebar-email');
    const avatarEl = document.getElementById('admin-sidebar-avatar');

    const name = user.name || user.firstName || 'Admin BuchiSapa';
    const email = user.email || 'admin@buchisapa.pe';
    const initial = (name.charAt(0) || 'A').toUpperCase();

    if (nameEl) nameEl.textContent = name;
    if (emailEl) emailEl.textContent = email;
    if (avatarEl) avatarEl.textContent = initial;
  }

  // Carga asíncrona no bloqueante de datos en paralelo
  function loadAllAdminDataAsync() {
    // 1. Cargar módulos críticos primero
    Promise.allSettled([
      window.fetchProducts?.(),
      window.fetchOrders?.(),
      window.fetchCaja?.()
    ]).then(() => {
      window.updateDashboardMetrics?.();
      // 2. Cargar módulos secundarios en segundo plano
      Promise.allSettled([
        window.fetchTickets?.(),
        window.fetchPortadas?.(),
        window.fetchPromociones?.(),
        window.fetchSupplies?.(),
        window.fetchUtensils?.()
      ]);
    });
  }

  function initApp() {
    setupEventListeners();
    setupSSEPushNotifications();

    // 1. Verificar sesión activa de Administrador localmente (0ms)
    const { isAuthorized, user } = getAdminAuthStatus();

    if (!isAuthorized) {
      showAdminLoginModal();
      return;
    }

    hideAdminLoginModal();
    updateAdminUserDisplay(user);

    // 2. Renderizar vista inmediatamente sin esperar por la red
    window.switchAdminView('dashboard');

    // 3. Cargar datos en segundo plano
    loadAllAdminDataAsync();
  }

  async function handleAdminLoginFormSubmit(event) {
    if (event && event.preventDefault) event.preventDefault();
    const emailInput = document.getElementById('admin-login-email');
    const passInput = document.getElementById('admin-login-password');
    const alertEl = document.getElementById('admin-login-alert');
    const submitBtn = document.getElementById('btn-admin-login-submit');

    const email = emailInput ? emailInput.value.trim() : '';
    const password = passInput ? passInput.value.trim() : '';
    const emailLower = email.toLowerCase();

    const showError = (msg) => {
      if (!alertEl) return;
      alertEl.innerHTML = `
        <div style="display: flex; align-items: center; gap: 8px; color: #ff4d79;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
          <span>${msg}</span>
        </div>
      `;
      alertEl.style.display = 'block';
      alertEl.style.background = 'rgba(255, 51, 102, 0.15)';
      alertEl.style.border = '1px solid rgba(255, 51, 102, 0.35)';
    };

    const showSuccess = (msg) => {
      if (!alertEl) return;
      alertEl.innerHTML = `
        <div style="display: flex; align-items: center; gap: 8px; color: #00ff88;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
          <span>${msg}</span>
        </div>
      `;
      alertEl.style.display = 'block';
      alertEl.style.background = 'rgba(0, 255, 136, 0.15)';
      alertEl.style.border = '1px solid rgba(0, 255, 136, 0.35)';
    };

    if (!email) {
      showError('Por favor ingresa tu correo de administrador.');
      if (emailInput) emailInput.focus();
      return;
    }

    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span>Verificando acceso...</span>';
    }

    try {
      let data = null;

      // Intento 1: Servidor Express (/api/auth/login)
      try {
        const res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: emailLower, password })
        });
        const resJson = await res.json().catch(() => null);
        if (res.ok && resJson && resJson.success) {
          data = resJson;
        } else {
          const errMsg = resJson?.error || resJson?.message || 'El correo electrónico o la contraseña ingresados no son correctos.';
          throw new Error(errMsg);
        }
      } catch (backendErr) {
        // Intento 2: Consulta directa a Supabase Auth si Express falló por red
        if (window.BuchisapaAPI && typeof window.BuchisapaAPI.loginAuth === 'function') {
          try {
            const sbRes = await window.BuchisapaAPI.loginAuth(emailLower, password);
            if (sbRes && sbRes.success) {
              data = sbRes;
            }
          } catch (sbErr) {
            // Ignorar fallo cliente Supabase
          }
        }
        if (!data) {
          throw backendErr;
        }
      }

      if (data && data.success) {
        const user = data.user || data.data;
        const isAdmin = Boolean(data.isAdmin || user.role === 'admin' || user.isAdmin === true);

        if (!isAdmin) {
          throw new Error('Esta cuenta no cuenta con privilegios de Administrador.');
        }

        const token = data.token || `admin-token-${Date.now()}`;
        localStorage.setItem('buchisapa_admin_token', token);
        sessionStorage.setItem('buchisapa_admin_session', JSON.stringify(user));
        localStorage.setItem('buchisapa_customer', JSON.stringify(user));

        showSuccess('¡Identidad confirmada! Ingresando...');

        hideAdminLoginModal();
        updateAdminUserDisplay(user);
        window.switchAdminView('dashboard');
        loadAllAdminDataAsync();
        return;
      }

      const errMsg = data?.error || data?.message || 'El correo electrónico o la contraseña ingresados no son correctos.';
      throw new Error(errMsg);

    } catch (err) {
      console.warn('Resultado de admin login:', err?.message || err);
      let userFriendlyMsg = err.message || 'Error al iniciar sesión en el panel.';
      const lower = userFriendlyMsg.toLowerCase();
      if (lower.includes('failed') || lower.includes('fetch') || lower.includes('unexpected') || lower.includes('json') || lower.includes('doctype') || lower.includes('syntaxerror') || lower.includes('typeerror') || lower.includes('network')) {
        userFriendlyMsg = 'El correo electrónico o la contraseña ingresados no son correctos.';
      }
      showError(userFriendlyMsg);
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = `<span>Ingresar al Panel</span> <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>`;
      }
    }
  }

  function fillAdminCredentials(email, pass) {
    const emailInput = document.getElementById('admin-login-email');
    const passInput = document.getElementById('admin-login-password');
    if (emailInput) emailInput.value = email;
    if (passInput) passInput.value = pass;
    const alertEl = document.getElementById('admin-login-alert');
    if (alertEl) {
      alertEl.style.display = 'none';
      alertEl.innerHTML = '';
    }
  }

  function toggleAdminPasswordVisibility() {
    const passInput = document.getElementById('admin-login-password');
    if (!passInput) return;
    passInput.type = passInput.type === 'password' ? 'text' : 'password';
  }

  function handleAdminLogout() {
    try {
      localStorage.removeItem('buchisapa_admin_token');
      localStorage.removeItem('buchisapa_admin_session');
      sessionStorage.removeItem('buchisapa_admin_session');
      localStorage.removeItem('buchisapa_customer');
      localStorage.removeItem('buchisapa_user_session');
      localStorage.removeItem('buchisapa_user_token');
      localStorage.removeItem('buchisapa_auth_user');
      localStorage.removeItem('buchisapa_user');
      localStorage.removeItem('buchisapa_token');
      sessionStorage.clear();
    } catch (e) {
      console.warn('Error al limpiar almacenamiento:', e);
    }
    
    window.location.replace('/');
  }

  function setupEventListeners() {
    // 1. Sidebar Nav Click Delegation
    const navItems = document.querySelectorAll('.sidebar-nav .nav-item');
    navItems.forEach(item => {
      item.addEventListener('click', () => {
        const view = item.dataset.view;
        if (view) window.switchAdminView(view);
      });
    });

    // 2. Mobile Drawer
    const btnMobileMenu = document.getElementById('btn-mobile-menu');
    const btnSidebarClose = document.getElementById('btn-sidebar-close');
    const sidebarOverlay = document.getElementById('sidebar-overlay');

    if (btnMobileMenu) btnMobileMenu.addEventListener('click', window.toggleMobileSidebar);
    if (btnSidebarClose) btnSidebarClose.addEventListener('click', window.closeMobileSidebar);
    if (sidebarOverlay) sidebarOverlay.addEventListener('click', window.closeMobileSidebar);

    // Logout Handler
    const btnLogout = document.getElementById('btn-admin-logout');
    if (btnLogout) {
      btnLogout.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (typeof window.handleLogout === 'function') {
          window.handleLogout();
        } else {
          localStorage.clear();
          sessionStorage.clear();
          window.location.href = '/index.html';
        }
      });
    }

    // 3. Category Filter Chips (Productos)
    const chips = document.querySelectorAll('.category-chip');
    chips.forEach(chip => {
      chip.addEventListener('click', () => {
        chips.forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        window.AdminState.currentCategory = chip.dataset.category || 'todos';
        window.applyProductFilters();
      });
    });

    // 4. Búsqueda en Topbar & Input de Catálogo de Productos
    const searchInputs = document.querySelectorAll('.admin-search-input');
    const clearCatalogSearchBtn = document.getElementById('btn-clear-catalog-search');

    searchInputs.forEach(input => {
      input.addEventListener('input', (e) => {
        const val = e.target.value || '';
        window.AdminState.searchQuery = val;
        
        searchInputs.forEach(otherInput => {
          if (otherInput !== input && otherInput.value !== val) {
            otherInput.value = val;
          }
        });

        if (clearCatalogSearchBtn) {
          clearCatalogSearchBtn.style.display = val.trim().length > 0 ? 'flex' : 'none';
        }

        window.applyProductFilters();
      });
    });

    if (clearCatalogSearchBtn) {
      clearCatalogSearchBtn.addEventListener('click', () => {
        searchInputs.forEach(input => { input.value = ''; });
        clearCatalogSearchBtn.style.display = 'none';
        window.AdminState.searchQuery = '';
        window.applyProductFilters();
        const catalogSearchInput = document.getElementById('catalog-search-input');
        if (catalogSearchInput) catalogSearchInput.focus();
      });
    }

    window.focusProductSearch = function () {
      if (typeof window.switchAdminView === 'function') {
        window.switchAdminView('productos');
      }
      setTimeout(() => {
        const catalogSearchInput = document.getElementById('catalog-search-input');
        if (catalogSearchInput) {
          catalogSearchInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
          catalogSearchInput.focus();
        }
      }, 100);
    };

    // 5. Select Ordenamiento Productos
    const sortSelect = document.getElementById('product-sort-select');
    if (sortSelect) {
      sortSelect.addEventListener('change', (e) => {
        window.AdminState.currentSort = e.target.value;
        window.applyProductFilters();
      });
    }

    // 6. View Mode Switcher (Grid vs Table)
    const btnGrid = document.getElementById('btn-view-grid');
    const btnTable = document.getElementById('btn-view-table');
    const gridContainer = document.getElementById('products-grid-container');
    const tableContainer = document.getElementById('products-table-container');

    if (btnGrid && btnTable) {
      btnGrid.addEventListener('click', () => {
        btnGrid.classList.add('active');
        btnTable.classList.remove('active');
        if (gridContainer) gridContainer.style.display = 'grid';
        if (tableContainer) tableContainer.style.display = 'none';
      });

      btnTable.addEventListener('click', () => {
        btnTable.classList.add('active');
        btnGrid.classList.remove('active');
        if (gridContainer) gridContainer.style.display = 'none';
        if (tableContainer) tableContainer.style.display = 'block';
      });
    }

    // 7. Modal Close Triggers
    const closeTriggers = document.querySelectorAll('.modal-close-trigger');
    closeTriggers.forEach(btn => {
      btn.addEventListener('click', () => {
        const modal = btn.closest('.modal-overlay');
        if (modal) modal.classList.remove('active');
      });
    });

    const overlays = document.querySelectorAll('.modal-overlay');
    overlays.forEach(overlay => {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) overlay.classList.remove('active');
      });
    });

    // 8. Formularios Modales
    const prodForm = document.getElementById('product-form');
    if (prodForm) prodForm.addEventListener('submit', window.handleProductFormSubmit);

    const cajaMovForm = document.getElementById('caja-movement-form');
    if (cajaMovForm) cajaMovForm.addEventListener('submit', window.handleCajaMovementSubmit);

    const cajaOpenForm = document.getElementById('caja-open-form');
    if (cajaOpenForm) {
      cajaOpenForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const initialInput = document.getElementById('modal-open-initial-cash');
        const cajeroInput = document.getElementById('modal-open-cajero');
        const initial = initialInput ? parseFloat(initialInput.value) || 250 : 250;
        const cajero = cajeroInput ? cajeroInput.value : 'Administrador';
        try {
          await window.AdminApi.abrirCaja(initial, cajero);
          window.showToast('Caja abierta con éxito', 'success');
          document.getElementById('caja-open-modal')?.classList.remove('active');
          await window.fetchCaja();
        } catch (err) {
          if (window.AdminState.cajaData) window.AdminState.cajaData.isOpen = true;
          window.renderCajaView();
          document.getElementById('caja-open-modal')?.classList.remove('active');
          window.showToast('Caja abierta localmente', 'info');
        }
      });
    }

    const cajaCloseForm = document.getElementById('caja-close-form');
    if (cajaCloseForm) {
      cajaCloseForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const realCashInput = document.getElementById('modal-close-real-cash');
        const notesInput = document.getElementById('modal-close-notes');
        const realCash = realCashInput ? parseFloat(realCashInput.value) || 0 : 0;
        const notes = notesInput ? notesInput.value : '';
        try {
          await window.AdminApi.cerrarCaja({ real_cash: realCash, notes });
          window.showToast('Turno cerrado (Reporte Z generado)', 'success');
          document.getElementById('caja-close-modal')?.classList.remove('active');
          await window.fetchCaja();
        } catch (err) {
          if (window.AdminState.cajaData) window.AdminState.cajaData.isOpen = false;
          window.renderCajaView();
          document.getElementById('caja-close-modal')?.classList.remove('active');
          window.showToast('Turno cerrado localmente', 'info');
        }
      });
    }

    const newTicketForm = document.getElementById('new-ticket-form');
    if (newTicketForm) {
      newTicketForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const select = document.getElementById('ticket-form-product-select');
        const selectedOpt = select ? select.options[select.selectedIndex] : null;
        const prodName = selectedOpt ? selectedOpt.textContent.split(' - ')[0] : 'Plato';
        const price = selectedOpt ? parseFloat(selectedOpt.dataset.price) : 18;
        const qty = parseInt(document.getElementById('ticket-form-quantity')?.value, 10) || 1;

        const ticketData = {
          number: `TK-${Math.floor(1000 + Math.random() * 9000)}`,
          customer: document.getElementById('ticket-form-customer')?.value || 'Cliente',
          phone: document.getElementById('ticket-form-phone')?.value || '',
          type: document.getElementById('ticket-form-type')?.value || 'Mesa',
          payment: document.getElementById('ticket-form-payment')?.value || 'Efectivo',
          items: [{ name: prodName, qty, price }],
          subtotal: price * qty,
          total: price * qty,
          status: 'Emitido',
          created_at: new Date().toISOString()
        };

        try {
          await window.AdminApi.createTicket(ticketData);
          window.showToast(`Ticket #${ticketData.number} emitido`, 'success');
          document.getElementById('new-ticket-modal')?.classList.remove('active');
          await window.fetchTickets();
          window.previewThermalTicket(ticketData.id || window.AdminState.allTickets[0]?.id);
        } catch (err) {
          window.AdminState.allTickets.unshift(ticketData);
          window.filterTickets();
          document.getElementById('new-ticket-modal')?.classList.remove('active');
          window.showToast(`Ticket #${ticketData.number} emitido localmente`, 'info');
          window.previewThermalTicket(ticketData.id || ticketData.number);
        }
      });
    }
  }

  function setupSSEPushNotifications() {
    try {
      const evtSource = new EventSource('/api/events');
      evtSource.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'order_created' || data.type === 'new_order') {
            window.showToast(`¡Nuevo pedido recibido! #${data.order?.orderNumber || data.order?.id}`, 'info');
            window.fetchOrders?.();
          } else if (data.type === 'order_status_updated') {
            window.fetchOrders?.();
          }
        } catch (err) {
          console.warn('Error al procesar evento SSE:', err);
        }
      };
    } catch (e) {
      console.warn('SSE no disponible:', e);
    }
  }

  window.handleAdminLoginFormSubmit = handleAdminLoginFormSubmit;
  window.fillAdminCredentials = fillAdminCredentials;
  window.toggleAdminPasswordVisibility = toggleAdminPasswordVisibility;
  window.handleAdminLogout = handleAdminLogout;
  window.handleLogout = handleAdminLogout;
  window.showAdminLoginModal = showAdminLoginModal;
  window.hideAdminLoginModal = hideAdminLoginModal;

})();
