(function(){
'use strict';
const viewMetadata={
 dashboard:{title:'Dashboard',desc:'Resumen general de la operación y de tu página de cliente.'},
 clientes:{title:'Clientes',desc:'Cuentas registradas y estado de los clientes.'},
 productos:{title:'Productos',desc:'Catálogo, precios, imágenes, disponibilidad y stock.'},
 categorias:{title:'Categorías',desc:'Organiza las 10 categorías que alimentan la carta digital.'},
 portada:{title:'Portadas',desc:'Administra los banners que aparecen en la página principal.'},
 pedidos:{title:'Pedidos',desc:'Supervisa pedidos y estados de preparación en tiempo real.'},
 ticket:{title:'Ticket',desc:'Emisión y control de comprobantes del sistema.'},
 insumos:{title:'Insumos',desc:'Control de materia prima y niveles de inventario.'},
 utensilios:{title:'Utensilios',desc:'Control de utensilios, equipos y estado operativo.'},
 configuracion:{title:'Configuración',desc:'Ajustes generales y conexión de la experiencia cliente.'}
};
function switchAdminView(id){ if(!viewMetadata[id]) id='dashboard'; document.querySelectorAll('.sidebar-nav .nav-item').forEach(x=>x.classList.toggle('active',x.dataset.view===id)); document.querySelectorAll('.admin-view').forEach(x=>x.classList.toggle('active',x.id===`view-${id}`)); const m=viewMetadata[id],t=document.getElementById('topbar-title'),d=document.getElementById('topbar-desc'); if(t)t.textContent=m.title;if(d)d.textContent=m.desc; window.scrollTo({top:0,behavior:'smooth'}); closeMobileSidebar(); setTimeout(()=>triggerRefresh(id),0);}
function triggerRefresh(id){ if(id==='dashboard')window.updateDashboardMetrics?.(); if(id==='clientes')window.fetchCustomers?.(); if(id==='productos')window.fetchProducts?.(); if(id==='pedidos')window.fetchOrders?.(); if(id==='ticket')window.fetchTickets?.(); if(id==='portada')window.fetchPortadas?.(); if(id==='insumos')window.fetchSupplies?.(); if(id==='utensilios')window.fetchUtensils?.();}
function toggleMobileSidebar(){document.getElementById('admin-sidebar')?.classList.toggle('open');document.getElementById('sidebar-overlay')?.classList.toggle('active');}
function closeMobileSidebar(){document.getElementById('admin-sidebar')?.classList.remove('open');document.getElementById('sidebar-overlay')?.classList.remove('active');}
window.switchAdminView=switchAdminView;window.toggleMobileSidebar=toggleMobileSidebar;window.closeMobileSidebar=closeMobileSidebar;window.handleLogout=window.handleLogout||function(){localStorage.clear();sessionStorage.clear();location.href='/index.html';};
document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('.nav-item').forEach(x=>x.addEventListener('click',()=>switchAdminView(x.dataset.view)));document.getElementById('btn-mobile-menu')?.addEventListener('click',toggleMobileSidebar);document.getElementById('btn-sidebar-close')?.addEventListener('click',closeMobileSidebar);document.getElementById('sidebar-overlay')?.addEventListener('click',closeMobileSidebar);});
})();
