# Categorías de productos

Cada categoría contiene:
- `banner.webp`: imagen principal/representativa de la categoría.
- `productos/`: imágenes individuales de los productos de esa categoría.

Categorías:
1. hamburguesas
2. salchipapas-y-salchibroasters
3. alitas
4. refrescos
5. platos-amazonicos
6. bebidas
7. broaster
8. infusiones
9. adicionales
10. promociones

Las carpetas `productos/` se mantienen listas para incorporar las imágenes de cada producto.
No se crean imágenes ficticias para banners que todavía no existan.
